<?php 
namespace Modul\Biaya_produksi\Controllers;
use App\Controllers\BaseController;
use Hermawan\DataTables\DataTable;
use Modul\Biaya_produksi\Models\Model_biaya_produksi;

class BiayaProduksi extends BaseController{

    public function __construct(){
        $this->biayaProduksi = new Model_biaya_produksi();
    }

    public function index(){

        $biayaProduksi = $this->db->query("SELECT * FROM biaya_produksi ORDER BY tanggal ASC")->getResult();
        $report = $this->db->query("SELECT b.id, b.nama_barang AS nama_barang, b.harga_jual AS harga_jual, b.harga_modal AS harga_modal,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.total ELSE 0 END) AS total_pendapatan,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.qty ELSE 0 END) AS qty_terjual FROM barang b 
             LEFT JOIN detail_penjualan dp ON dp.id_barang = b.id LEFT JOIN penjualan p ON dp.id_penjualan = p.id 
             GROUP BY b.id, b.nama_barang, b.harga_jual, b.harga_modal")->getResult();    

        $totalHpp = 0;
        foreach($report as $key => $data){
            $hpp = $data->harga_modal * $data->qty_terjual;

            $totalHpp += $hpp;
        }

        $data_page = [
            'menu'      => 'pencatatan',
            'submenu'   => 'biaya-produksi',
            'title'     => 'Data Biaya Produksi',
            'biaya_produksi'  => $biayaProduksi,
            'balance' => $totalHpp,
            // 'pelanggan' => $pelanggan
        ];

        return view('Modul\Biaya_produksi\Views\viewBiayaProduksi', $data_page);

    }

    public function datatable()
    {
        $id_toko = $this->session->get('id_toko');
        $startDate = $this->request->getPost('dari');
        $endDate = $this->request->getPost('sampai');
        $tanggalAwal = $this->db->query("SELECT DATE(MIN(tanggal)) AS tanggal_awal FROM biaya_produksi")->getResult();
        $tanggalAkhir = $this->db->query("SELECT DATE(MAX(tanggal)) AS tanggal_akhir FROM biaya_produksi")->getResult();
        $tanggalAwalResult = $tanggalAwal[0]->tanggal_awal;
        $tanggalAkhirResult = $tanggalAkhir[0]->tanggal_akhir;
    
        $builder = $this->db->table('biaya_produksi as b')
            ->select('b.id as id, b.nominal as nominal, b.deskripsi as deskripsi, b.foto as foto, b.tanggal as tanggal')
            ->where('b.id_toko', $id_toko)
            ->orderBy('b.id', 'DESC');

        if ($startDate != "" && $endDate != "") {
            $builder->where('b.tanggal >=', $startDate);
            $builder->where('b.tanggal <=', $endDate);
        }else if($startDate != "" && $endDate == ""){
            $builder->where('b.tanggal >=', $startDate);
        }else if($startDate == "" && $endDate != ""){ 
            $builder->where('b.tanggal <=', $endDate);
        }
        

        return DataTable::of($builder)
            ->addNumbering('no')
            ->setSearchableColumns(['LOWER(b.deskripsi)'])
            ->add('action', function ($row) {
                return '<button type="button" class="btn btn-light" title="Edit Data" onclick="edit(\'' . $row->id . '\')"><i class="fa fa-edit"></i></button>
                <button type="button" class="btn btn-light" title="Hapus Data" onclick="hapus(\'' . $row->id . '\', \'' . $row->foto . '\')"><i class="fa fa-trash"></i></button>';
            })->add('nominal', function ($row) {
                return 'Rp. ' . number_format($row->nominal);
            })->add('foto', function ($row) {
                if ($row->foto) {
                    return '<image data-fancybox data-src="/assets/img/biaya-produksi/' . $row->foto . '" src="/assets/img/biaya-produksi/' . $row->foto . '" height="70" style="cursor: zoom-in; border-radius: 5px;"/>';
                } else {
                    return '<image src="/assets/img/noimage.png" height="70" style="cursor: zoom-in;"/>';
                }
            })
            ->toJson(true);
    }

    public function simpan(){

        $rules = $this->validate([
            'nominal' => [
                'label' => 'Nominal',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi!'
                ]
            ],
            'deskripsi' => [
                'label' => 'Deskripsi',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi!'
                ]
            ],
            'foto' => [
                'label' => 'Foto',
                'rules' => 'max_size[foto, 1024]|ext_in[foto,jpg,png,jpeg]',
                'errors' => [
                    'max_size' => 'Ukuran {field} terlalu besa!',
                    'ext_in' => '{field} harus JPG, PNG atau JPEG!'
                ]
            ],
            'tanggal' => [
                'label' => 'Tanggal',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi!'
                ]
            ]

        ]);

        if(!$rules){
            $errors = [
                'nominal' => $this->validation->getError('nominal'),
                'deskripsi' => $this->validation->getError('deskripsi'),
                'foto' => $this->validation->getError('foto'),
                'tanggal' => $this->validation->getError('tanggal')
            ];

            $respond = [
                'status' => FALSE,
                'errors' => $errors
            ];
        }else{
            $id = $this->request->getPost('id');
            $id_toko = $this->session->get('id_toko');
            $nominal = $this->request->getPost('nominal');
            $deskripsi = $this->request->getPost('deskripsi');
            $tanggal = $this->request->getPost('tanggal');
            $foto = $this->request->getFile("foto");

            $data = [
                'id' => $id,
                'id_toko' => $id_toko,
                'nominal' => getAmount($nominal),
                'deskripsi' => $deskripsi,
                'tanggal' => $tanggal,
            ];

            if($foto->isValid() && !$foto->hasMoved()){
                $namafile = $foto->getRandomName();
                $foto->move(ROOTPATH . 'public/assets/img/biaya-produksi/', $namafile);

                if($id){
                    $foto = $this->db->table('biaya_produksi')->select('foto')->where('id', $id)->get()->getRow();
                    $path = 'assets/img/biaya-produksi';
                    $unlink = @unlink($path . $foto->foto);
                }
                
                $data['foto'] = $namafile;
            }

            $save = $this->biayaProduksi->save($data);

            if($save){
                if($id){
                    $notif = "Data Berhasil diperbaharui";
                } else{
                    $notif = "Data Berhasil ditambahkan";
                }

                $respond = [
                    'status' => TRUE,
                    'notif' => $notif
                ];
            } else{
                $respond = [
                   'status' => FALSE 
                ];
            }
        }
        echo json_encode($respond);
        
    }

    public function getdata(){
        $id = $this->request->getPost('id');

        $data = $this->db->table('biaya_produksi')
            ->where('id', $id)
            ->get()->getRow();

        if ($data) {
            $response = [
                'status' => TRUE,
                'data'   => $data
            ];
        } else {
            $response = [
                'status' => false,
            ];
        }

        echo json_encode($response);

    }

    public function hapus(){
        $id   = $this->request->getPost('id');
        $foto = $this->request->getPost('foto');

        // Unlink IMG
        $path = 'assets/img/biaya-produksi/';
        $unlink = @unlink($path . $foto);

        if ($this->biayaProduksi->delete($id)) {
            $response = [
                'status' => true,
            ];
        } else {
            $response = [
                'status' => false,
            ];
        }

        echo json_encode($response);
    }

    public function fetchBalance(){
        $dariTanggal = $this->request->getPost("dari");
        $sampaiTanggal = $this->request->getPost("sampai");

        $dariTanggalTime = date('Y-m-d H:i:s', strtotime($dariTanggal));
        $sampaiTanggalTime = date('Y-m-d H:i:s', strtotime($sampaiTanggal));

        // dd($dariTanggalTime, $sampaiTanggalTime);
        $tanggalTerlama = $this->db->query("SELECT DATE(MIN(tgl)) AS tanggal_terlama FROM penjualan")->getResult();
        $tanggalTerbaru = $this->db->query("SELECT DATE(MAX(tgl)) AS tanggal_terbaru FROM penjualan")->getResult();

        // dd($tanggalTerbaru[0]->tanggal_terbaru);
        if($dariTanggal != "" && $sampaiTanggal != ""){
            // dd("MASOK 1", $dariTanggal, $sampaiTanggal);
            // dd("MASOK 1", $dariTanggalTime, $sampaiTanggalTime);
            $report = $this->db->query("SELECT b.id, b.nama_barang AS nama_barang, b.harga_jual AS harga_jual, b.harga_modal AS harga_modal,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.total ELSE 0 END) AS total_pendapatan,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.qty ELSE 0 END) AS qty_terjual FROM barang b 
             LEFT JOIN detail_penjualan dp ON dp.id_barang = b.id LEFT JOIN penjualan p ON dp.id_penjualan = p.id 
             WHERE p.tgl BETWEEN '$dariTanggalTime' AND '$sampaiTanggalTime' GROUP BY b.id, b.nama_barang, b.harga_jual, b.harga_modal")->getResult();   
             
        }else if($dariTanggal != "" && $sampaiTanggal == ""){
            // dd("MASOK 2", $dariTanggal, $sampaiTanggal);
            // dd("MASOK 2", $dariTanggalTime, $sampaiTanggalTime);
            $report = $this->db->query("SELECT b.id, b.nama_barang AS nama_barang, b.harga_jual AS harga_jual, b.harga_modal AS harga_modal,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.total ELSE 0 END) AS total_pendapatan,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.qty ELSE 0 END) AS qty_terjual FROM barang b 
             LEFT JOIN detail_penjualan dp ON dp.id_barang = b.id LEFT JOIN penjualan p ON dp.id_penjualan = p.id 
             WHERE p.tgl BETWEEN '$dariTanggalTime' AND (SELECT MAX(tgl) AS tanggal_terbaru FROM penjualan) GROUP BY b.id, b.nama_barang, b.harga_jual, b.harga_modal")->getResult();    

        }else if($dariTanggal == "" && $sampaiTanggal != ""){
            // dd("MASOK 3", $dariTanggal, $sampaiTanggal);
            // dd("MASOK 3", $dariTanggalTime, $sampaiTanggalTime);
            $report = $this->db->query("SELECT b.id, b.nama_barang AS nama_barang, b.harga_jual AS harga_jual, b.harga_modal AS harga_modal,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.total ELSE 0 END) AS total_pendapatan,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.qty ELSE 0 END) AS qty_terjual FROM barang b 
             LEFT JOIN detail_penjualan dp ON dp.id_barang = b.id LEFT JOIN penjualan p ON dp.id_penjualan = p.id 
             WHERE p.tgl BETWEEN (SELECT MIN(tgl) AS tanggal_terlama FROM penjualan) AND '$sampaiTanggalTime' GROUP BY b.id, b.nama_barang, b.harga_jual, b.harga_modal")->getResult();    

        }else{
            // dd("MASOK 4", $dariTanggal, $sampaiTanggal);
            // dd("MASOK 4", $dariTanggalTime, $sampaiTanggalTime);
            $report = $this->db->query("SELECT b.id, b.nama_barang AS nama_barang, b.harga_jual AS harga_jual, b.harga_modal AS harga_modal,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.total ELSE 0 END) AS total_pendapatan,
             SUM(CASE WHEN dp.id_barang = b.id THEN dp.qty ELSE 0 END) AS qty_terjual FROM barang b 
             LEFT JOIN detail_penjualan dp ON dp.id_barang = b.id LEFT JOIN penjualan p ON dp.id_penjualan = p.id 
             GROUP BY b.id, b.nama_barang, b.harga_jual, b.harga_modal")->getResult();    

        }


        // dd($report);
        $totalHpp = 0;
        foreach($report as $key => $data){
            $hpp = $data->harga_modal * $data->qty_terjual;

            $totalHpp += $hpp;
        }

        if ($report) {
            $response = [
                'status' => TRUE,
                'balance'   => $totalHpp
            ];
        } else {
            $response = [
                'status' => false,
            ];
        }

        echo json_encode($response);
    }
    
}